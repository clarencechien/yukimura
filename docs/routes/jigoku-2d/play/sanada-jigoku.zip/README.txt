真田・六文劫 — 燼關突圍

解壓縮後，以 Chrome、Edge 或 Firefox 開啟 index.html。無需安裝或啟動伺服器。
WASD／方向鍵移動、按住 J 連槍、空白鍵衝刺、K 無雙、R 集合／突進。
手機以左搖桿與右側按鈕操作；手機系統可能限制下載 HTML 執行，這時請使用 HTTP 版本。
Phaser 3.90 MIT 授權附於 PHASER-LICENSE.md。
這是架空修羅戰境的 2D 關卡原型，沒有真實 3D 模型或真人動作捕捉。
